package com.teksystems.capstone1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Capstone1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

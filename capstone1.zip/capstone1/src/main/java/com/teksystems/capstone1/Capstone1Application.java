package com.teksystems.capstone1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Capstone1Application {

	public static void main(String[] args) {
		SpringApplication.run(Capstone1Application.class, args);
	}

}
